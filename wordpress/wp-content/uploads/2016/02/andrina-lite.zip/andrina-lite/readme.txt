Thank you for downloading Andrina Wordpress Theme.

To Install Andrina Theme, Put the "Andrinatheme" directory in your wp-content/themes directory and Activate the Theme from Wordpress Admin Panel.

The Theme installs with the basic layout in place. You can configure the Home Page using the Themes Options Panel.

If you want to build a blog, use the Template Type as "Blog Page" from the Page Attributes Section within the Add new Page section. The blog would come up in the page you created.

The process is similar for creating the Contact us page and the gallery page. In the gallery page you need to upload the images using the upload image buttons and just have to save the changes. Nothing is needed to be appeared in the page as you hit publish, a nice gallery would come up. 

Complete Theme Documentation in PDF & Video Format is Available at InkThemes.com

If you have any questions that are beyond the scope of this help file, please feel to ask question on our support forum at InkThemes.com or Mail Us at support@inkthemes.com