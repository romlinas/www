<?php 
/*
 * Banner Code Template for the Header
 *
 * It is recommended to set up a child theme and copy this file inside your child theme folder.
 * In this case, any code you put in here will not be lost once you update Newswire theme.
 */ 
?>

<!-- Add 468x60 Banner Code Below This Comment -->

